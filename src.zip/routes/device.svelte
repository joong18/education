<div>
    <div class="p-5">디바이스 관리 페이지</div>
    <div class="max-w-sm bg-white rounded-lg border border-gray-200 shadow-md ">상자</div>
</div>


