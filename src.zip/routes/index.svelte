<script>
    import { Alert } from "flowbite-svelte";
  </script>
<Alert id="alert-blue">
    <span slot="content">
      <span class="font-medium">
        Info alert!
      </span>
      Change a few things up and try submitting again.
    </span>
  </Alert>
<h1 class="text-3xl font-bold underline">
    Hello world!
</h1>